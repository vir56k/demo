执行构建
    make build

启动
    make run
    
构建且启动    
    make build && make run